<?php
    if(isset($_POST['id'])){
        $id = $_POST['id'];
        $sql = 'delete from nhanvien where id= '.$id;
        $conn =  mysqli_connect("localhost","root","","ltw_bt3");
        mysqli_query( $conn ,$sql);
        mysqli_close($conn);
        echo 'Xóa thành công';
    }
?>