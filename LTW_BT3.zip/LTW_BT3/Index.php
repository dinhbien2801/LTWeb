<?php
session_start();
if (!isset($_SESSION["login"])) {
    header("location:login.php");
}
require_once 'dbhelp.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bài Tập 3</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <style>
        body {
            color: #566787;
            background: #f5f5f5;
            font-family: 'Varela Round', sans-serif;
            font-size: 13px;
        }

        .jumbotron {
            background-color: #2196F3;
            color: #fff;
        }

        .table-wrapper {
            background: #fff;
            padding: 20px 25px;
            margin: 30px 0;
            border-radius: 1px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.247);
        }

        .table-title {
            padding-bottom: 15px;
            background-color: #2195f3;
            color: #fff;
            padding: 16px 30px;
            margin: -20px -25px 10px;
            border-radius: 1px 1px 0 0;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.247);
        }

        .table-title h2 {
            margin: 5px 0 0;
            font-size: 24px;
        }


        .table-title .btn {
            color: #fff;
            float: right;
            font-size: 13px;
            border: none;
            min-width: 50px;
            border-radius: 5px;
            border: none;
            outline: none !important;
            margin-left: 10px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.247);
        }

        .table-title .btn i {
            float: left;
            font-size: 21px;
            margin-right: 5px;
        }

        .table-title .btn span {
            float: left;
            margin-top: 2px;
        }

        table.table tr th,
        table.table tr td {
            border-color: #e9e9e9;
            padding: 12px 15px;
            vertical-align: middle;
        }

        table.table tr th:first-child {
            width:20px;
        }

        table.table tr th:last-child {
            width: 50px;
        }

        table.table-striped.table-hover tbody tr:hover {
            background: #f5f5f5;
        }

        table.table th i {
            font-size: 10px;
            margin: 0 5px;
            cursor: pointer;
        }

        table.table td:last-child i {
            opacity: 0.9;
            font-size: 22px;
            margin: 0 5px;
        }

        table.table td a {
            font-weight: bold;
            color: #566787;
            display: inline-block;
            text-decoration: none;
            outline: none !important;
        }

        table.table td a:hover {
            color: #2196F3;
        }

        table.table td a.edit {
            color: #FFC107;
        }

        table.table td a.delete {
            color: #F44336;
        }

        table.table td i {
            font-size: 10px;
        }

        table.table .avatar {
            border-radius: 1px;
            vertical-align: middle;
            margin-right: 10px;
        }

        .pagination {
            /* float: right; */
            padding-left: 20px;
            margin: 0 0 5px;
        }

        .pagination li a {
            border: none;
            font-size: 13px;
            min-width: 30px;
            min-height: 30px;
            color: #999;
            margin: 0 2px;
            line-height: 30px;
            border-radius: 1px !important;
            text-align: center;
            padding: 0 6px;
        } 

        .pagination li a:hover {
            color: #666;
        }

        .pagination li.active a,
        .pagination li.active a.page-link {
            background: #2195f3;
        }

        .pagination li.active a:hover {
            background: #0397d6;
        }

        .pagination li.disabled i {
            color: #ccc;
        }

        .pagination li i {
            font-size: 16px;
            padding-top: 6px
        }

        .hint-text {
            float: left;
            margin-top: 10px;
            font-size: 13px;
        }

        .modal .modal-dialog {
            max-width: 400px;
        }

        .modal .modal-header,
        .modal .modal-body,
        .modal .modal-footer {
            padding: 20px 30px;
        }

        .modal .modal-content {
            border-radius: 1px;
        }

        .modal .modal-footer {
            background: #ecf0f1;
            border-radius: 0 0 1px 1px;
        }

        .modal .modal-title {
            display: inline-block;
        }

        .modal .form-control {
            border-radius: 1px;
            box-shadow: none;
            border-color: #dddddd;
        }

        .modal .btn {
            border-radius: 1px;
            min-width: 100px;
        }

        .modal form label {
            font-weight: normal;
        }

        .logo {
            padding-left: 50px;
            color: #2196F3;
        }

        .glyphicon .glyphicon-user {
            width: 30px;
            height: 30px;
        }
    </style>
</head>

<body id="myPage">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div>
                <ul class="nav navbar-nav navbar-left">
                    <li><a href="#"><span class="glyphicon glyphicon-user"></span>
                            <?php
                            if (isset($_SESSION["login"])) {
                                echo $_SESSION["login"][4];
                            }
                            ?></a></li>
                </ul>
            </div>
            <div>
                <ul class="nav navbar-nav">
                    <li><a href="#manageEmployees">QUẢN LÝ NHÂN VIÊN</a></li>
                    <li><a href="#STAT">THỐNG KÊ</a></li>
                    <li><a href="#strategy">MỤC TIÊU</a></li>
                    <li><a href="#about">SỰ KIỆN</a></li>
                    <li><a href="#address">ĐỊA CHỈ</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> ĐĂNG XUẤT</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- <div class="jumbotron text-center" style=" padding-bottom: 0;">
        <h1>QUẢN LÝ NHÂN SỰ</h1>
        <img src="https://timviec365.vn/pictures/images/quan-ly-nhan-su-bao-gom-nhung-viec-gi%20(1).jpg" width="100%" height="280">
    </div> -->

    <div id="manageEmployees" class="container" >
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2>QUẢN LÝ NHÂN VIÊN</h2>
                    </div>
                    <div class="col-sm-6">
                        <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xe147;</i> <span>Thêm mới</span></a>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Họ và tên</th>
                        <th>Email</th>
                        <th>Địa chỉ</th>
                        <th>SĐT</th>
                        <th>PB</th>                        
                        <!-- <th>Tùy chọn</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sqlt = 'select count(id) as number from nhanvien';
                    $conn =  mysqli_connect("localhost", "root", "", "ltw_bt3");
                    $resultset = mysqli_query($conn, $sqlt);
                    $result = [];
                    while ($row = mysqli_fetch_array($resultset, 1)) {
                        $result[] = $row; //trả về các hàng kq lưu vào mảng result
                    }
                    mysqli_close($conn);
                    $number = 0;
                    if ($result != null && count($result) > 0) {
                        $number = $result[0]['number'];
                    }
                    $page = ceil($number / 5);
                    $current_page = 1;
                    if (isset($_GET['page'])) {
                        $current_page = $_GET['page'];
                    }
                    $index = ($current_page - 1) * 5;

                    $sql = 'select * from nhanvien limit ' . $index . ',5' ;
                    // $nvlist = executeResult($sql); 
                    if(isset($_POST['search']) && $_POST['search']!=''){
                        $s=$_POST['search'];
                        $sql = "select * from nhanvien where fullname like '%$s%' ";
                        $_POST['search']='';
                    }
                    $conn =  mysqli_connect("localhost", "root", "", "ltw_bt3");
                    $resultset = mysqli_query($conn, $sql);
                    $list = [];
                    while ($row = mysqli_fetch_array($resultset, 1)) {
                        $list[] = $row;
                    }
                    $i = $index;
                    mysqli_close($conn);
                    foreach ($list as $nv) {
                        $i++;
                        echo '<tr>
                            <td>' . $i . '</td>
                            <td>' . $nv['fullname'] . '</td>
                            <td>' . $nv['email'] . '</td>
                            <td>' . $nv['diachi'] . '</td>
                            <td>' . $nv['sdt'] . '</td>
                            <td>' . $nv['phongban_id'] . '</td>

                            <td>
                            <div class="inline_block" style="float: right;">
                                <button class="btn btn-warning" style="color: black;padding-right:20px" onclick=\'window.open("Fix.php?id=' . $nv['id'] . '","_self")\'>Sửa</button>
                                <button class="btn btn-danger" onclick="deleteNV(' . $nv['id'] . ')">Xóa</button>
                            </div>                               
                            </td>
                        </tr>';
                    }
                    ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-sm-4">
                    <form class="form-inline" method="POST" >
                        <div class="form-group">
                            <!-- <label for="username"></label> -->
                            <input type="text" class="form-control" id="search" placeholder="nhập từ khóa" name="search">
                        </div> 
                        <button type="submit" class="btn btn-primary" >Tìm Kiếm</button>
                    </form>
                </div>
             
                <div class="col-sm-6">
                    <ul class="pagination" style="text-align: center;">
                        <?php
                        for ($i = 1; $i <= $page; $i++) { ?>
                            <!-- echo'<li class="active"    ><a href="?page='.$i.'">'.$i.'</a></li>'; -->
                            <li class="<?php echo ($current_page == $i) ? 'active' : '' ?>"><a href="?page=<?php echo $i ?>"><?php echo $i ?></a></li>
                        <?php }   ?>
                    </ul>
                </div>
                
                <div class="col-sm-2" >
                    <form method="POST" action="Excel.php">
                            <button type="submit" class="btn btn-success" id="btnExp" name="btnExp" style="float: right;">Xuất Excel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function deleteNV(id) {
            option = confirm('Bạn có muốn xóa nhân viên này không');
            if (!option) {
                return;
            }
            // console.log(id);
            $.post('delete.php', {
                'id': id
            }, function(data) {
                alert(data);
                location.reload();
            })
        }
    </script>

    <div id="addEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" action="Add.php">
                    <div class="modal-header">
                        <h4 class="modal-title">Thêm nhân viên</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="fulln">Họ và Tên</label>
                            <input type="text" class="form-control" required="true" id="fulln" name="fulln">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" required="true" id="email" name="email">
                        </div>
                        <div class="form-group">
                            <label for="dc">Địa chỉ</label>
                            <textarea class="form-control" required="true" id="dc" name="dc"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="sdt">SĐT</label>
                            <input type="text" class="form-control" required="true" id="sdt" name="sdt">
                        </div>
                        <div class="form-group">
                            <label for="pb">phong ban</label>
                            <input type="text" class="form-control" required="true" id="pb" name="pb">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="HỦY">
                        <input type="submit" class="btn btn-success" name="form_click" value="LƯU">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div>
        <div id="STAT" class="container text-center">
            <h1>THỐNG KÊ</h1>
            <canvas id="myChart" style="width:100%;max-width:900px; padding-left: 350px;"></canvas>
            <script>
                var xValues = ["Marketing", "Ý tưởng", "Bán hàng", "Chăm sóc khách hàng", "Nhân viên Thẩm định"];
                var yValues = [15, 10, 35, 28, 12];
                var barColors = ["red", "green", "blue", "orange", "brown"];

                new Chart("myChart", {
                    type: "bar",
                    data: {
                        labels: xValues,
                        datasets: [{
                            backgroundColor: barColors,
                            data: yValues
                        }]
                    },
                    options: {
                        legend: {
                            display: false
                        },
                        title: {
                            display: true,
                            text: "Thống kê nhân viên tại các phòng ban",
                            fontSize: 25,
                        },
                        scales: {
                            yValues: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            </script>
        </div>

    </div>
    <div id="strategy" class="container text-center" style="padding-bottom: 50px; padding-top: 50px;">
        <h1>
            MỤC TIÊU SẮP TỚI</h1>
        <div class="row">
            <div class="col-sm-4" style="background-color:yellow;">
                <h2>Tháng 1 năm 2022</h2>
                <p>Lorem ipsum dolor sit amet,
                    consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                    nisi ut aliquip ex ea commodo consequat.</p>
                <span class="glyphicon glyphicon-user logo" style="font-size: 200px; padding-top: 30px;padding-right: 40px;"></span>
            </div>
            <div class="col-sm-4" style="background-color:pink;">
                <h2>Tháng 6 năm 2022</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                    nisi ut aliquip ex ea commodo consequat
                    . Excepteur sint occaecat cupidatat</p>
                <span class="glyphicon glyphicon-signal logo" style="font-size: 200px; padding-top: 30px;padding-right: 40px;"></span>
            </div>
            <div class=" col-sm-4" style="background-color:greenyellow;">
                <h2>Tháng 12 năm 2022</h2>
                <p>non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
                    consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                <span class="glyphicon glyphicon-home logo" style="font-size: 200px; padding-top: 30px;padding-right: 40px;"></span>
            </div>

        </div>

    </div>

    <div id="about" class="container-fluid text-center ">
        <h2>SỰ KIỆN</h2><br>
        <h4>Những dấu mốc đáng nhớ</h4>
        <div class="row text-center">
            <div class="col-sm-4">
                <div class="thumbnail">
                    <img src="https://cybershow.vn/wp-content/uploads/2019/04/company-trip-long-hai-1.png" width="400" height="300">
                    <p><strong>Du Lịch</strong></p>
                    <p>Tham quan du lịch Nha Trang 5-2019</p>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="thumbnail">
                    <img src="https://cybershow.vn/wp-content/uploads/2020/02/company-trip-prudential-3-1280x720.jpg" width="400" height="300">
                    <p><strong>Cuộc thi</strong></p>
                    <p>Hoạt động ngoại khóa của công ty 7-2020</p>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="thumbnail">
                    <img src="https://cdn.brvn.vn/editor/2020/05/cybershowvna01_1588581861.jpg" width="400" height="300">
                    <p><strong>Kỉ Niệm</strong></p>
                    <p>10 năm ngày thành lập công ty 22-12-2020</p>
                </div>
            </div>
        </div>
    </div>

    <div id="address" class="container-fluid text-center">
        <h1>
            ĐỊA CHỈ</h1>
        <div class="col-sm-8">
            <div>
                <h3>97 Khương Trung, Thanh Xuân, Hà Nội</h3>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.8476844350416!2d105.81657631327992!3d20.99874189418207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac8f8ad28e61%3A0xfc49dafb5c1e336b!2zOTcgUGjhu5EgS2jGsMahbmcgVHJ1bmcsIEtoxrDGoW5nIFRydW5nLCBUaGFuaCBYdcOibiwgSMOgIE7hu5lpLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1636255410452!5m2!1svi!2s" width="700 px" height="300 px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
        <div class="col-sm-4">
            <div>
                <h3>fanpage công ty</h3>
                <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FTong.Cong.Ty.CP.Bao.Hiem.Buu.Dien&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="700" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
            </div>
        </div>
    </div>

    <footer class="container-fluid text-center">
        <a href="#myPage" title="To Top">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a>
        <!-- <p>Bootstrap Theme Made By <a href="https://www.w3schools.com" title="Visit w3schools">www.w3schools.com</a></p> -->
    </footer>

    <script type="text/javascript">
        $(document).ready(function() {
            // Activate tooltip
            $('[data-toggle="tooltip"]').tooltip();

        });
    </script>

    <script>
        $(document).ready(function() {
            // Add smooth scrolling to all links in navbar + footer link
            $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

                // Make sure this.hash has a value before overriding default behavior
                if (this.hash !== "") {

                    // Prevent default anchor click behavior
                    event.preventDefault();

                    // Store hash
                    var hash = this.hash;

                    // Using jQuery's animate() method to add smooth page scroll
                    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
                    $('html, body').animate({
                        scrollTop: $(hash).offset().top
                    }, 900, function() {

                        // Add hash (#) to URL when done scrolling (default click behavior)
                        window.location.hash = hash;
                    });
                } // End if
            });
        })
    </script>

</body>

</html>