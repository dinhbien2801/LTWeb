<?php
// require_once 'define.php';
//tao ket noi toi db
$connect = new mysqli("localhost","root","","ltw_bt3");
mysqli_set_charset($connect,"utf8");
//kiem tra ket noi cos thanh cong ko
if($connect->connect_error){
    var_dump(($connect->connect_error));
    die();
}
?>