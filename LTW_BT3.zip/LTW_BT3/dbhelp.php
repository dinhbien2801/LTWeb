<?php
session_start();
// require_once 'connect.php'; 

function execute($sql){
    $conn =  mysqli_connect("localhost","root","","ltw_bt3");
    mysqli_query( $conn ,$sql);
    mysqli_close($conn);
}
function executeResult($sql){
    $conn =  mysqli_connect("localhost","root","","ltw_bt3");
    $resultset = mysqli_query( $conn ,$sql);
    $list = [];
    while($row = mysqli_fetch_array($resultset,1)){
        $list[] = $row ;
    }
    mysqli_close($conn);
    return $list;
}
?>