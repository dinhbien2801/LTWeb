<?php
//dong ket noi
$connect->close();
?> 