<?php
$conn =  mysqli_connect("localhost", "root", "", "ltw_bt3");
// mysqli_set_charset($connect, "utf8");
//kiem tra ket noi cos thanh cong ko
if ($conn->connect_error) {
    var_dump(($conn->connect_error));
    die();
}
$out = '';
if (isset($_POST['btnExp'])) {
    $sql = "select * from nhanvien";
    $resultset = mysqli_query($conn, $sql);
    if (mysqli_num_rows($resultset) > 0) {
        $out .= '
            <table class="table" bordered="1">
                <tr>
                    <th>fullname</th>
                    <th>email</th>
                    <th>diachi</th>
                    <th>sdt</th>
                </tr>
            ';
        while ($row = mysqli_fetch_array($resultset)) {
            $out .= '
                <tr>
                     <td>' . $row["fullname"] . '</td>
                     <td>' . $row["email"] . '</td>
                     <td>' . $row["diachi"] . '</td>
                    <td>' . $row["sdt"] . '</td>           
                </tr>
                '; 
        }

        $out .= '</table>';
        header("content-Disposition:attachment; filename = download2.xls");// lưu file dạng đính kèm vs tên filename
        header("content-Type: application/xls"); // chọn kiểu định dạng lưu file.xls
        // header("content-Type: application/vnd.openxmlformats-officedocument spreadsheetml.sheet");
        echo $out;// hiển thị dữ liẹu
    }
}
?>