<?php
    $fulln= $email =$sdt = $dc = $pb='';
    if(!empty($_POST)){
        $id= '';
        if(isset($_POST['fulln'])){
            $fulln =$_POST['fulln'];
        }
        if(isset($_POST['email'])){
            $email =$_POST['email'];
        }
        if(isset($_POST['dc'])){
            $dc =$_POST['dc'];
        }
        if(isset($_POST['sdt'])){
            $sdt =$_POST['sdt'];
        }
        if(isset($_POST['pb'])){
            $pb =$_POST['pb'];
        }
        if(isset($_POST['id'])){
            $id=$_POST['id'];
        }
        if($id!= ''){
            $sqlt = "Update nhanvien set fullname='$fulln', email ='$email', diachi='$dc', sdt ='$sdt', phongban_id='$pb' where id='$id'";
        }
        $fulln = str_replace('\'','\\\'',$fulln);
        $email = str_replace('\'','\\\'',$email);
        $dc = str_replace('\'','\\\'',$dc);
        $sdt = str_replace('\'','\\\'',$sdt);
        $pb= str_replace('\'','\\\'',$pb);
        $id= str_replace('\'','\\\'',$id);
       
        $conn =  mysqli_connect("localhost","root","","ltw_bt3");
        mysqli_query( $conn ,$sqlt);
        mysqli_close($conn);  
        header('Location: Index.php');
        die();
    }
    $id='';
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = 'select * from nhanvien where id= '.$id;
        $conn =  mysqli_connect("localhost","root","","ltw_bt3");
        $resultset = mysqli_query( $conn ,$sql);
        $list = [];
        while($row = mysqli_fetch_array($resultset,1)){
            $list[] = $row ;
        }
        mysqli_close($conn);
        if($list !=null && count($list) > 0){
            $nv =$list[0];
            $fulln =$nv['fullname'];
            $email=$nv['email'];
            $dch =$nv['diachi'];
            $sdt =$nv['sdt'];
            $pb =$nv['phongban_id'];
        }else{
            $id='';//th id trên url bị sửa ko có trong db thì gán lại =''
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
 <div >
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post" >
                    <div class="modal-header">
                        <h4 class="modal-title">Sửa nhân viên</h4>
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> -->
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="fulln">Họ và Tên</label>
                            <input type="number" name="id" value="<?=$id?>" style="display: none;">
                            <input type="text" class="form-control" required="true" id="fulln" name="fulln" value="<?=$fulln?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" required="true" id="email" name="email"  value="<?=$email?>">
                        </div>
                        <div class="form-group">
                            <label for="dc">Địa chỉ</label>
                            <input class="form-control" required="true" id="dc" name="dc"  value="<?=$dch?>"></input>
                        </div>
                        <div class="form-group">
                            <label for="sdt">SĐT</label>
                            <input type="text" class="form-control" required="true" id="sdt" name="sdt"  value="<?=$sdt?>">
                        </div>
                        <div class="form-group">
                            <label for="pb">phong ban</label>
                            <input type="text" class="form-control" required="true" id="pb" name="pb" value="<?=$pb?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="Index.php"><input type="button" class="btn btn-default"  value="HỦY"></a>
                        <input type="submit" class="btn btn-success" name="form_click" value="LƯU">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>