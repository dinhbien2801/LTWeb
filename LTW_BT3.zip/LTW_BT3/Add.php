<?php
if(!empty($_POST)){
    $fulln= $email =$sdt = $dc = $pb='';
    if(isset($_POST['fulln'])){
        $fulln =$_POST['fulln'];
    }
    if(isset($_POST['email'])){
        $email =$_POST['email'];
    }
    if(isset($_POST['dc'])){
        $dc =$_POST['dc'];
    }
    if(isset($_POST['sdt'])){
        $sdt =$_POST['sdt'];
    }
    if(isset($_POST['pb'])){
        $pb =$_POST['pb'];
    }
    $fulln = str_replace('\'','\\\'',$fulln);
    $email = str_replace('\'','\\\'',$email);
    $dc = str_replace('\'','\\\'',$dc);
    $sdt = str_replace('\'','\\\'',$sdt);
    $pb= str_replace('\'','\\\'',$pb);
    $sqlt = "insert into nhanvien(fullname , email , diachi , sdt , phongban_id ) value ('$fulln','$email','$dc',' $sdt','$pb')";
    $conn =  mysqli_connect("localhost","root","","ltw_bt3");
    mysqli_query( $conn ,$sqlt);
    mysqli_close($conn);  
    header('Location: Index.php');
    die();
}