<?php
const host ="localhost";
const username ="root";
const pwd ="";
const db ="ltw_bt3";
?>